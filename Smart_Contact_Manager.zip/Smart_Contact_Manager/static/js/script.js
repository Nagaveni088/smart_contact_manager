// Smart Contact Manager

console.log("Smart Contact Manager Loaded Successfully");

// Navbar shadow on scroll
window.addEventListener("scroll", function () {

    const navbar = document.querySelector(".navbar");

    if (window.scrollY > 30) {
        navbar.classList.add("shadow");
    } else {
        navbar.classList.remove("shadow");
    }

});

// Show alert when page loads
window.onload = function () {

    console.log("Website Ready!");

};