from flask import Flask, render_template, request, redirect, url_for, session
from pymongo import MongoClient

app = Flask(__name__)
app.secret_key = "smart_contact_manager"

# ==========================
# MongoDB Connection
# ==========================

client = MongoClient("mongodb://localhost:27017/")
db = client["smart_contact_manager"]

users = db["users"]
contacts = db["contacts"]

# ==========================
# HOME
# ==========================

@app.route("/")
def home():
    return render_template("index.html")


# ==========================
# REGISTER
# ==========================
@app.route("/register", methods=["GET", "POST"])
def register():

    if request.method == "POST":

        name = request.form["name"]
        phone = request.form["phone"]
        email = request.form["email"]
        password = request.form["password"]
        confirm_password = request.form["confirm_password"]

        # Check passwords
        if password != confirm_password:
            return "Passwords do not match!"

        # Check duplicate email
        if users.find_one({"email": email}):
            return "Email already registered!"

        # Save to MongoDB
        users.insert_one({
            "name": name,
            "phone": phone,
            "email": email,
            "password": password
        })

        return redirect(url_for("login"))

    return render_template("register.html")


# ==========================
# LOGIN
# ==========================

@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "POST":

        email = request.form["email"]
        password = request.form["password"]

        user = users.find_one({
            "email": email,
            "password": password
        })

        if user:

            session["user"] = user["name"]
            session["email"] = user["email"]

            return redirect("/dashboard")

        return "Invalid Email or Password"

    return render_template("login.html")


# ==========================
# DASHBOARD
# ==========================

@app.route("/dashboard")
def dashboard():

    if "user" not in session:
        return redirect("/login")

    total_contacts = contacts.count_documents(
        {"owner": session["email"]}
    )

    return render_template(
        "dashboard.html",
        username=session["user"],
        total=total_contacts
    )


# ==========================
# CONTACTS
# ==========================

@app.route("/contacts")
def contact_list():

    if "user" not in session:
        return redirect("/login")

    my_contacts = list(
        contacts.find(
            {"owner": session["email"]}
        )
    )

    return render_template(
        "contacts.html",
        contacts=my_contacts
    )


# ==========================
# ADD CONTACT
# ==========================

@app.route("/add-contact", methods=["GET", "POST"])
def add_contact():

    if "user" not in session:
        return redirect("/login")

    if request.method == "POST":

        name = request.form["name"]
        phone = request.form["phone"]
        email = request.form["email"]
        category = request.form["category"]
        address = request.form["address"]
        notes = request.form["notes"]

        contacts.insert_one({

            "owner": session["email"],
            "name": name,
            "phone": phone,
            "email": email,
            "category": category,
            "address": address,
            "notes": notes

        })

        return redirect("/contacts")

    return render_template("add_contact.html")

# ==========================
# OTHER PAGES
# ==========================

@app.route("/about")
def about():

    total_contacts = 0

    if "email" in session:
        total_contacts = contacts.count_documents(
            {"owner": session["email"]}
        )

    return render_template(
        "about.html",
        total=total_contacts
    )


@app.route("/contact-us")
def contact_us():
    return render_template("contact_us.html")


@app.route("/settings")
def settings():
    return render_template("settings.html")


@app.route("/contact")
def contact():
    return render_template("contact.html")


@app.route("/edit-contact")
def edit_contact():
    return render_template("edit_contact.html")


# ==========================
# LOGOUT
# ==========================

@app.route("/logout")
def logout():

    session.clear()

    return redirect("/")


# ==========================
# RUN
# ==========================

if __name__ == "__main__":
    app.run(debug=True)